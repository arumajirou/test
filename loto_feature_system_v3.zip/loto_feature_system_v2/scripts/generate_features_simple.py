#!/usr/bin/env python
"""
シンプルな特徴量生成スクリプト
基本的なパイプラインを使用して特徴量を生成します
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import yaml
import pandas as pd
import logging
from tqdm import tqdm
from core.database_manager import DatabaseManager
from core.data_loader import DataLoader
from pipelines.basic_stats import BasicStatsPipeline
from pipelines.calendar_features import CalendarFeaturesPipeline

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """メイン処理"""
    # 設定読み込み
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'db_config.yaml')
    
    if not os.path.exists(config_path):
        logger.error(f"設定ファイルが見つかりません: {config_path}")
        return 1
    
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    logger.info("=== 宝くじ時系列特徴量生成 ===\n")
    
    # データ読み込み
    logger.info("データ読み込み中...")
    data_loader = DataLoader(config)
    
    try:
        df_dict = data_loader.load_by_series('nf_loto_final')
        logger.info(f"読み込み完了: {len(df_dict)}系列\n")
    except Exception as e:
        logger.error(f"データ読み込み失敗: {e}")
        logger.info("nf_loto_finalテーブルが存在することを確認してください")
        return 1
    
    # パイプライン初期化
    logger.info("パイプライン初期化中...")
    pipelines = {
        'basic_stats': BasicStatsPipeline(),
        'calendar': CalendarFeaturesPipeline()
    }
    logger.info(f"パイプライン数: {len(pipelines)}\n")
    
    # 特徴量生成
    logger.info("特徴量生成中...")
    hist_features = []
    futr_features = []
    
    for (loto, unique_id), df in tqdm(df_dict.items(), desc="系列処理"):
        # 各パイプラインで特徴量生成
        for pipeline_name, pipeline in pipelines.items():
            try:
                features = pipeline.generate(df)
                
                if len(features) == 0:
                    logger.warning(f"{pipeline_name} で {loto}/{unique_id} の特徴量生成失敗")
                    continue
                
                # メタデータ追加
                features['loto'] = loto
                features['unique_id'] = unique_id
                
                # 特徴量タイプに応じて分類
                if pipeline.get_feature_type() == 'hist':
                    hist_features.append(features)
                elif pipeline.get_feature_type() == 'futr':
                    futr_features.append(features)
                    
            except Exception as e:
                logger.error(f"{pipeline_name} で {loto}/{unique_id} の処理中にエラー: {e}")
                continue
    
    # 統合
    logger.info("\n特徴量統合中...")
    
    if hist_features:
        hist_df = pd.concat(hist_features, ignore_index=True)
        logger.info(f"Historical特徴量: {len(hist_df)}行 × {len(hist_df.columns)}列")
    else:
        hist_df = pd.DataFrame()
        logger.warning("Historical特徴量が生成されませんでした")
    
    if futr_features:
        futr_df = pd.concat(futr_features, ignore_index=True)
        logger.info(f"Future特徴量: {len(futr_df)}行 × {len(futr_df.columns)}列")
    else:
        futr_df = pd.DataFrame()
        logger.warning("Future特徴量が生成されませんでした")
    
    # データベース保存
    logger.info("\nデータベース保存中...")
    db_manager = DatabaseManager(config)
    
    try:
        if not hist_df.empty:
            rows = db_manager.upsert_features(hist_df, 'features_hist')
            logger.info(f"features_hist へのUPSERT完了: {rows}行")
        
        if not futr_df.empty:
            rows = db_manager.upsert_features(futr_df, 'features_futr')
            logger.info(f"features_futr へのUPSERT完了: {rows}行")
        
        logger.info("\n=== 完了 ===")
        return 0
        
    except Exception as e:
        logger.error(f"データベース保存失敗: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
